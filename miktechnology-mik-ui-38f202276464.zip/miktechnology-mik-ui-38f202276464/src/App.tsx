import { useEffect, useState, useRef, useMemo } from 'react';
import { Textarea, TextareaDesc, CloseSvg, AppBox, LeftBox, RightBox, TabsPan1, TabsPan2, PaneItem, SliderSetting, PlayingIcon, SwitchBox, SwitchBox2, Line } from './App.styles'
import { Tabs, Slider, notification, Switch, Button, Modal, Input } from 'antd';
import { getRandomString } from './utils/index'

const accessTokenUrl = 'https://openapi.baidu.com/oauth/2.0/token';
const text2audioUrl = 'http://tsn.baidu.com/text2audio';
const API_KEY = 'xPzZxzNOniKU5YC2VurMdXkq'
const SECRET_KEY = 'GGHTo1gBDmLGmOI7GqKRNy8eEEiC1L2E'

const defaultMale = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAADahJREFUaAXNWwuMVOUV/u6d92PfO8uCsCworCgCriAQqZSUtkCxFrVatK2mbbRt0qYJtj4SG1ITq60mTU2a2NRGq4JSpS9rsaWCAgIV0KIiD4XVXdiFZZd9znvm9jt35i53Z2d25s4MbX9y9/7zP84533/O/R/nPyi4QOkv+9Z7hxFekkTyKkBt0RStRQEaNQ0VioIKYcv8IPODGtClaMoRIHlEhbrfB/fO6+avD14I0ShD+dLmf69vCMeDt5LiDYCyUNM0ZzHUFUWJcjj2su9mt9274Ya5688UQydbn7IAfuHAPdfGNe2H1NIKDZo9G6NiyxQocVrHFrui/PyW1kfeKJaO0a8kwC/su39ZAomfEOQSg+CFfBP8TsWmPLD2yoe3F8unKMAv7bt/YgTxx/jtrbXCONgRRLg7gtDpMDwNbtTOq+bnbV0E9tjogn3djfMf6rTCX9pa5vb8gXtWJpPYSK1WWWHWd6gf3bt7cOqfnUiEE3pXZ40Ts749E3ULaq2Q0ttS2/2qirVfaX3kb1Y6q1Yab9h377qEhpetghUew21DaP9rxwhYKYuei+Lgw+9j4OiA/LSURAaRRWSy0rEgDb9y7Jeuvv5TT2hI3m6FuLnt7rv2IkRzzpZq51Rj3vo52aoKKlOgPl1dNemuVTO+n52BiUpeDW86cF+gb6BjWylgYwOxnGBFloHjQwidCpvEspYV2URGkTVfz3EBi2bjWuJP3CAszkdovHq71w7VntuYHKwf+mRoPBJ560RGkVVkHq/xuIB1My4RrDBXCLZmbk1OOSqm++EJuHPWF1ohoEXm8drnBCyTQSlmnMl05p0z4KhwZBbDVetA4Oo6+Ai6HElkHm8iy2pnsvTIDMjNbs4BGU+46S90Y2CGB2db/fq3e/LFdpzZ3Y3wUCxrN2+1C4FrA2ha0wRHlR0Tt/ZBTQInP8d1upikKEmbgtXZlqwxgFObisQHxSw9hmwzf9OJya/2Ycs1LuzZdQrxBKUvIDlcdixfMBFLdoRw9JsT0L66roBe2ZvIOu2CbVbm5mSMBlM7KGubCjPLqS+dhfNsDDGayLLXQ6hN7THMTXLmmyIKFu8IYpjTTtXBICZu78/ZNl+FKEywZLYbBXjj2/d+2up2MZNg72VehA8OwM4ZxM2N3O0cu4r0hk7Myc/8RNjQyMdr2ujJ79u0Sv5V4IpoGOJS1T/Tk0ne0m/BIpjMnUadbLSE9qC5spj8u9s6sSPch5uVCkzRHKgmhG8QdCfiaIFLHwQz3UEkcVSJoEVzsTb1hR1HFJt6hzB5lw9Tvtxkbm45n8b0KaPjiIY3HLhvKc2gpFPP8IlhnNh6EhFo6NYS6EfKnhtgx1xCFY1npgqouErzUPMqewFn2adXSRKyhhObPkGkJ+/mKZPkqN+CSbAZhSOANS1xt1FY7PvUk2260MMirBKDj9rNTAnWiVaH+AhAc0qZvIrDhCtDJZPdyQ3t5iZF5c3Y9CHXPRWx0EmOxigTt0Jdto8779hDEBrm0zjXaLoXR4d1iAAO0YnRpkXRr4yGWUfNToMDs2nSM5BykMhQPKUM4CPE4PbYsfh3i8FzsBVxRrUVJ4Lb4blIPCc6QHHLUIyiwQr14K5zOtgmkvliGuw7COPvGD4PMovMPRySHn4E+/gdN9AirtN8mE7ga0njV0ofekNx9H8wgOrZlk6jowCLItOup18YJk0fVGkpcSzlc7te8xM48DwG8HuFM22GRnNxcdpUnKEhP0nNvqIMw0PNr+A8LinRVhZ/no7RLt7FQYQW0mmWS5aCyiN9UcyhKQeopWcp9FGasZW0csHFcNhVvLTzCHYhRGPWIIM3mVYS77ZGKztfZaFgtYsrtVjvoplwbDiO+XRSblO4S7IIttbnxjULmuBxujAUimLL/hP4lxLmssbZXXGhLVyaMkROwShYuWUVv3Hpyeu0oYra3Q5r5ufldvK7a+bD4+VpiRPTF5ZciotqfbpAYtrTuJbbXFk+/iJEFqz8htWWIvqO6VKj2rBfX4HHVOUsCFR68YObFmLCZNOERLNe3jpd7xOiWcvyZneNXd5yEh23Qm2x0+fbUuLnq7Pw2Wycacf3WoiermiuR2dvEHOm1WPV0hY4PRm+ejaaO6MR9tfeQzyp4V0OYrOzpAVkZAgEq/ghGkv/QrhJqHdwAUpREmBuB/fKTgdqKt0IVPlwycRq1NNUO3oGcNOyBtQ0cJ2WhuYkv0nCwX5TG6vw0ak+bkkTuKSpdOeAsBGsssdP7RDMjIvIxxZWAltTHadPqKKpLtK/SX1155LDVQbRSBzTL6bbifkRqzKPtuTToGtrfDpgma0T8yqy7NmsCylYVeNiy3r38z1cCQWBZh4TSEySx00ztfO740QGalomI7DO6abHwwxWGqe6SO58YpmvIuWaCtR5UR8f1011vl+enGAV9iUlJ8EuP+zHojdsmFyXMhaHADUDEc0ZmjS0KPXmcrMULFf4/Uq6clIDlr7tREtveUCrVPOgmZfVfGXEBrU9jPChQcwMpFwy9mz7XmMAjLcBXBgaZSbm8XgK8OWOKoT296MuyEEsMQlWMemSAEccSdjrnHBMcmPRVc26SHF6O+Tyd1QyfspbHkPD0siok7K0N2hoKIxJtX40zQnAMdWDiL0wN5GQy5UEq528utigOVejfOWDBPzWjCjqGzzgkompk6oxyN3SKLWZNWgANUAaDIxBkHruv8+eC+KKa5rQMduGmEfBsUBp52JhI1jtcvPO0wSn1OJTR3UM8khqWNGI9j+2pzSsUfpMYGY2BngpM/LSnk+MN3aRr9fibVvI3KOkvGDlpJU8UhKVjM7+lQGeXVUk4jTBtPB6EwEkyXhLPttgsOzkmUEsWj4NqixnZU0MqZCYinLSlIP6glXT0XGGN4Lm79gAZ7wzmconKnXsI0dF72fyXhNlUsj7W7CqEkCSiqnI277gBrGV1VA5lJDJS4AUMt8IWPHrcDmqrPegqz5eML9CGgpGwaqmomX0AJJC+hXUJuLkrHAFXawCQJ+x+c6mWV2j6Tp9YFjAPh9OLS/YlNDaXsFqfCSbU4Xl+/vOpVEMu4lCZJc1Vdce8wJSwMlbkuSNgWHbnkq6bZuzX8no7Yv/o2PUAUtokDi6iqc1tmeC+4Q3W6MI2YlGAMf4mIELSMElFpCu6/cmsLt1/BPXWE75S3QnHjFKSx2wePN4dNqSv6u1FkOeBF5bHMGAW0BTlQIwJu80SAMsy7qq49i2kK4dG+vKnASbEetlmDQkDqrMfHRyUW5Mjk0IozfG6J1EDHECT6afeDyhl/XE6RZqpuvdvGSVURgzthHAEvRF1e8sI5/zpLini/PfIH3TvbYwzjpC+iP5QW7PElyKyq/XFHvBZA5oGwEs1TbYfnxeyvLlNF6djKT0jkrlDsRJL4nfRScB/VlqtgPHSKfiMxLIZu49CvAt8x/aRnk2mhuUI59UVNh5PvbQVVPBs3Kdn2fcSh+qfR54XS56OOjCYZtyJ8GSGbU3xlkkEW4RJFbRyEyeteJEqeu3YVqnAxP6bHBWEpCc8ETDaS3rVAWn7M6OuDhx2dA2KY5zfpnCS0s0ZbkQX5dJRViPSaWEPDQc5rXob/tho/exZsWUFEjxnAkw4zFzFGs3nvTy1fuHj5GotuO971Sir1E6WUxWQh4M0umglkeN3+O9K9pjmP3nKAJ7grAx+Cyi8qRtS6DyxilwzpJ4SvY2NGu8haDMVOaHwENvdiP4WhequJAz2AnRmV6c+mwFDn7egYQcZgtIDFS7+9b5Dz+WrWlWDRsNCfqpXJE8Km/pJzMW4/IXg3C3ZWwWSLWfy1GcJlwhoC+jg084ibyZHI0yvkOMxQy+2qlfjPujozWr+RwIXu3Hh6t9OH65IeHYt0TlEewdY2tSJZnsR7XTQw4lCs8Uq+XviGHay0E0bR2Gc8g0+47qyR+kPEAvRYz26ppdA1drNRwXMzQpkyM3H9HDgwi/1YMowxzcDBzy00823qLcN8+LD9Z40bWA7lvTuHD1211dOXnZeCGImewzxYaE80mEW8370cUzNw1i4h4LB3J6LkIUKETzFp+cwu9a9dNQGZok++fEQBwaQ5k0VorH0xNX4U7mFWlExuFGO46v9uPjFT7EK5TddsV2/c2tP+0eaZAlUxB1beX3XOF9vU/wQur2LDTyF5FLjODjfASPRAEIY37qVJAKB992C0AzGcY96tOnv1Rz14zHH8/rByoIsMEg2HDbOu4hfsYly2RIRu1//82lJ0lJfuQ981zWCSqbRJYAC4Fw4LaV1DQDxHlZ+D9MFLyfh/q17u7nLlyAuOATBtwIzlJUpew7skLHT3iLDFbBCn3LGjYLFWr86qeRSD7IWXyJufxC5Tmv7YRNfcDT9ez2YnmUBNhgGqr/2lIeEO5WNI3/jccUHNNA8o1sJRN7G2tyOTLkcnAa28pGt4PtzvGdTizlf+NRtiia+qjn7DOvG+XFvkmvfElr+NaESDK0lufaGzAbC7UrlfOXv6fJ5x9ct2Xp9pGtrFMyEHJltIpzYOpaiuWcinYkovhE2ctJfbPLpm5QTj/z//UftSjymKStv9MbGY4wfoQhFZrWQrNvUYaURs2lVCjOpA5PiyiDdCwNal6ti+Z6hDeMRxRF3e/yuXYq639tLXZijATZC/4D/wcOmTk3cRIAAAAASUVORK5CYII='
const male = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAADZJJREFUaAXFW3twlNUV/327m91kN5uFEMiT8DQBFOVhQdqgqK0lqDh16jjgH7TTaZlx7PQPcTp2am3rTP+wMlOrU8dHnRGnoHZqBYEgEuURobHhKVBCwiMBkoUNIZtk37vf13O+3bv59ss+sptNe4fNvffcc849v/s8934XCRMUqto+tZLqBgXyUgmGekhKvQKlQlJgh0Q/DgqGFAlDEiQnFKmdeNuJ9yiVtPTc/ahX5cnzHymf+uac/GyaNxxYL0F5nPQuVxSYc9EvSQiSXKsC6WOrybL1wl3fv5GLnmQyeQE8/diueyNK5DkCuJq6zZSsotxpUpgaYI9RMv7xypKHD+auJyo5LsDVbTvvp2H4exqqDeM1ZCzyNPRbDEbphauLH90/Fv5kPDkBntG2pzKE4GYCui6Z0ommEfBtBTA/23X36t5s68oacM2xHY2yrGxTAEe2leWTnwx3GwzSuqtL1jZlo9eQDXN12/ZnI4qy8/8Nlm1mG9gWtikbDGPq4bkduy1ed+RNmq8bslE+Vl5zvweSLCM42QrFaByrWJyPtrL3rA7jxs7b1gTixBSJjIDnHts91auEtyuKsiKFDpVs9Idg76ApRUu1CNW+IIojssimjof9uEli7sICDNVVwV85KTVvihJJko5YJdNjnUvWuFKwqOS0gNWeHQx/mQksa1r4/FbY26+lqytjWXFpMboX1ODSU/ciUJ79EqGCLjHdn66n085hdRhn6FmBovD6LZHMOR7uH0bZvzox+cTlnHRwx7DN6YRTAubFYKLmbDqD5HAYtX8/jPmv70Vx1810rEnL2OZ0C1lSwOrWI+HlpBr/B0RexCq/PItprR2w9mQ/cmSynTEkM3UUYHYqeJ+ldX9UWTIFghZ02EQyL7FEix8dLGCixTDrQLYzBsailx0FKupBZe9UuJfO1uvOOU/uoyorySMrfrbKSNLBWPRyCYBrjn+6Kld38coTK+BeWKvXn1PebIqaFbFaEJjEp8zcAmNhTFrphJONHFFe0hZmk45YCnDmd0+i4Udv4OHbq+hcmNCW2aiCkaza1XIBYasZAdqqxhNimFYKHXHANMnvi8h5OPWYTHjwntkoKCLVhTQ0C6gqvfPEI5VHLfskHEfoxzTOByjhVxCigrOUHW+gXm5gbORzH2Bd8W6g6bJpvMqFvMlIag1keFy7KNHEAjTHzMfAOfD8pfzM6uy9raiC0X+12FST+KYiengfzZwLhQ7sZLRAoNHA4NL9BCuJ2sw5XZYIDQkxY2OMTFQB87UMWRIf3gncY8iYCMUGVz82d/bQ0sjjMwaWI4GbgXIQsT6t45NohDzZO4DfdvWi3p/xTKCqTv1HMUUxxgDH7qBS82coedrVh58fu4IVe7tREOaJGEMlelPIJwOr5eG0Cpwsok141tl+NB7pwTuXujE5EhZacooFRkPsdnF5TlpiQss8HgTaPZADMk1BTbcKgFpQLCPoolJRHqdHExItdoFOL4qHQpg37l7GcsbKw7iBxvi4JkybzYp5dTZEhmXMdpamBiQAilgA5Tynua3ioIEZ9WUwSxZ47Ca0FxYyV86BMZL6BhM520tz1hIT/EvZVAwvNuBOtx/VcycDXrpSFmAEEG0lGlBaclyGiLZJNnxTX4KThUZsLZ+C/hwuBhJ0U4axmviSnBL6sqzyQRrG75SXAeVRseOHz5B2dTIm9Fi890QjiH1YNADH6k+Cq9iCZ+ZNz8qOTMyM1cBfBDIxZl+uAysAaRUJmj5WRQVRK5CHNGGlIa1U5EFVogq2VztohP36mKX0NM7T6KBPMnkPjNWgfuvJs2paIGJDk2LNLhWvJjYA4nktuBj/gFnvj8a5c04wVhrSsQ9bOasZLRjm5ZaPdgI4s4g0x6L39TT2WVguouB8kYWl8hsIq+pp5VcrcNlGuxwbT4ar4ARAbc8yWG3gPPOpPazg1dmxFVDLk4e0gVp+KA96ElS8WFcDsGPElxUMQAUfSwvwDFCA5Fg0EMVX6ajp5wNIvgNhNdD6kHfA/7FZcIIu1REidEH6MXgBXIDjPP9EPkwJ+sn0++lds/INVdXHWOlMQx+jJyD8eOFM3KKzMdjvDxEYPudyjzN47k0GK0ZBkMtoDaWvwi8sqIKTLuQnIjBWGtJS+0QoZ50P3FOvNin8hE4FTDGD45+aj8WUVqgxNi6agd1T83cOHoWLsNIhTJ4wwFzh13SuHfIG1KHKNxkqeNEAPgaqICCHcYm6/N/kTk5kYKzsWh6lxETWo4Id8tHYptr4usdArijdHVOgBqBtSGJHg+6vJjowVj4ttVD9wfGemLIxViYPwFRggJGci4ICI3hBviVNzLwVdjFGat8WQ+y1TKsoyGdcWTBypDPSXZWZLvZsDjMc04pgK7OgsKQARgtvP9Td9K/UZEaRIf8eVgxTK2NVr3X4tQwNr5X5AltsMOFX1fPxoKMcx64OosTjg2QjIHwi5RrV4ZxYm8lWjPfmLKPFWsHz3afQ7s/vbhnFGLvi4adBZAVvEjkHibwq24kh1B324aO6FWicXAmzwYBlDzRCmjs3qlcAFTFTaRrDMQWVjU+ixmLFrEIb3r9tOR44a4S91Q2Jt7RxBykcxRgDzO+gaIzvyUWvgbaTkq/dqHitC6VNfQi23ECRb0STgQ/ua9YCdQtGiAIDx+U1wMPrYdDcUkbIWend141JX/Sj8tXLcLQMwOjLfWFlbOKtV9x/43dQIxaNMTXoR/mfL8LR3A8TbTEcIvTFf/fndAGgDyu/B9TfFaWKHq6eA6z6ATV73Ay1fE/zWQx7+G0aLercoIduEfBLMFzO/kuiqkODLV4TP/qizaFFrSXdHz77ne6C481m2F7cB1NQWD8itHvvGYTU28sRmpr61n2AfcSxUG6/h2ZSonyEpsb2Xad0gsSmGGB7vQ3Ff/gnTAfomwRvc2MIjEn7oC0OmGVpn/pNSh19Q7BvPwrLpi0IvfwJbtI1Tsmk2UnZB4f82N9yPqGM2ykQpF5bSCA51NbR3C2FPxDtySgR+PLQedyk78PJQsnkmXB3OOH76+fAL97F5HcPAh09yVjjNH7IFs9QIrF5iVDVtmMr+T/rVCZ6WWM51Q07GeFsO0d3xdFhy2V2xwxMrYoNUZU58c+M6aV47eUn4kSf3w9zAW1DPKc//wBYsRoonqQ2gpG2IpOJ6BSefvZDXO0ZiMvpEwN959HvOpdALq2tgGHVHXB/mxZH+uIoAvXutp67164XeY55k0gI/MItNOheU3ak0+HZdxzu6/0YTuCIZqhRIMshmn7JHYauK/04ceoaFt1ZjWCQPo1J5GiIm8eVj9GHtiJVkYUWK4/XR2WFaG3rSgtWUWRyzPjkkRj6u+n8s8UJ84cHUbFqEW6sqoNcPcXNWBI5k/QwM9QsbmykobaT9oyEIa8XNposKJ06n6bldCoaNViwZFEtXtj0kDpsbdYoQL0OzgdDIVrsIvj1S7vRcTH5qyPPUC9u3jiDcJCugDMGSZ65sO6Rtg/faNKzRseRjjro7OwsnjrbQwP4IV1RQlaRI/AOO+H1uFBcUqP2opah1+nGssU1mFJqpx5M3Xbc88dOduOTXd9oxWNpBc6rbRjoa4ccoSV7DIHurZ7r2P/RlmSsKa24cbZ5M717ei+ZkJZmNFtRVnEHDe2kbYem5nPkL4+aOVoVanrnHlp5kwaJRtECmC2OpKV6ItvMtuvpIp8SMDM4as0b+bGXYNbH1uIKTJ95LyyF9LUhRTjw1QXaU9NvIRcv38TJ09dSaCCP1GJD1cwGmjq1KXm4gG1lm9MxJe+WmER/Z2ekpGbeDkWWG4jEEzUaaAGaMm0B9exCSCl6VrDSaxrY6Oi3YF6lII2K395yGN1X0zsVvOjZ7BUwmW3wDfM8T/S8GKzRbH6s+1DT4KgKNIS0Pcx8zuNNLmq1+0lhfHhXTl9G7u8cjZr0yV2fnaEVfWRL03I7rw/icOtFLSlt2u6oQfWs7ySsF2wb28i2phWmwrQ9LIS5p72uS5/QQjZMp47vhoIeqdhelbF3hbyP3lpV0YPRmbX0ZVEXtnzQmnJl1rGqWV64XD0nEAqxcyLJvEC5zjb/km1Mxq+nZexhrYC6kBmVRwL+AXfvlSO0lSR6SVpefXr77tHu4oDbh+aD5/WsKfPhkA/XLn8Fn7ePJ6xbIlvSLVDJFGUFmBW4vvmiCYWm+SH/wLbeLgIdTr8giUovXHLhzDlyEDRhBzVCSH0ioSGmSAYDblzrOoRQcJCfj2xjG1RbUvCnIo9pSOuFvb0Xhj2uS/+wldUc8Hhcc632yloDHfozBS+9n165Ijr3fb4QXnm9eUyAfZ4+9Ha3QpFDLSaDYcP1M82b2YZM9SUrz2xlMqkYzXl6335KrqSrz/vKpy/bZCooWk1LU0qdrW2Xcd01hPKpdvUI6fVmnhLD7mthl/P4HkWSXuk73XwgjTljKhrtD45JLDnT8nV/KkfIQAcP5XHytZeTu23Wc65tvBMb1i/HT575GwbcKdxEunAjx7+VDgofD/R3bL1+au8NvZ5c83kFrDXi0Z+9ab3RH6D9W1lKvV5PF5X1lK6wWgvsT/1wmf2t97+irET/DU+hyyvJSTe19N/w0E7po9NKLS2fvrUxRWtoa8k+/V9llB5C7GY47gAAAABJRU5ErkJggg=='
const female = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAADbRJREFUaAXFW3twVNUZ/919ZnfzIm8SQiCACCKPQACHtOjUByBqsdoOtlOUMtra1nbU9o/O2HHqdKZTdfrwD9uOUnUsVAs+ABGnKChBoAYQqkCQVyEBkpDFZJNsNtnd2993d29ys9zd7Iv205t79pzvfN/3O+fc833ngYKrRJVNm90U3aAiPFeBZSoUdaoKtUJRkQeFj5AKn6rAp0C5CFVpJm8zefezpPH8vDv6NJ4s/1GyKW/SoffK+oKB+xSod1PuAlWFIx35ioIB1tunQnnDbXOuOznrtvZ05JjVyQrg6gPvfDWkhn5GgEvYbTYzRennKUE2wDarYn36XN3tH6UvJ1IzI8BVTVtu4jD8FYdqQ6aGJFOfQ7/RYlWeaJlzx85k+M140gJc07Rt7CAGniXQlWZC4+W5W7xwdnQjp60LgbICXJ49HqrFEo89bj6Br7fD8dh/5i25EJcpTkHKgMcd2LQ0HFbXq0BBHJmm2QVHWlC85wQq3j8MS/+gxjMwxoOT378VnfW1pnUSZdLwLotFWdlSd+e7ifhiy1Jq3qqmtx8LqeqWVMGK0twz7ah8Z/8QWMlzXO7FtN+8hfzj5+VnSiQ2iC1iUyoVkwI8+YutTrqZl8LAM3QlSdWJNaLq7abYrMhvznQ163abl42WS1vEJrFNbByNXcpHNX7yga2lfd3BHZycViUj0IzH3u2Ho8NnVqTleU61wXX+y7jloxWIbWKj2Doab0LA0mp9avBtVVVvGE1QovKQ20FnFV9V2J0Dz9nMXK3YKLaO1tPxrSCCvq7QnzMFKw0Rtlnx5ayauG3iqy1DoLQwbnmyBRpo2pyIPy5gmQwyGcaxSk88eDOCea7YbAwUeeCdPxm+2lFH4xV1zTLE5kQTmalbEtcjM2C6E9QDrx3C0Skl2FtXpfndSRv20SUdh9rTb2YjUOjBha9Ow7kV8zFQ4MKy7SdgDavYfOsUc/7RchWErYqy3MxlXQE4ElQEjqbjenQ7fvLCPtz53nH8flEFunZ/jnAopBclfCtOO6rrp+OhXa147nv12LB8ekL+RIXip+1wTosNTq4Y0pEIKrWgwqj4OxsPo+RSL0KhMH70YStKQmy6JKk2AKzZ1YIup4I5hy/itp0nk6x5JZt0mGCJLRkBeNzBzTemGi7GCjwwvQJjD5+Dnf41h+vAVWqBth4UPhlOufw7FlZU8HFrOREJ8vvbaj7/KvAEwsilq/r8msy+a8EimCIaIn9HrGzCIfUpY2E6adeOT7Gp34tvKnmoVu0oJITVBH0BQUyFU2sEo1wfwjiuBDBVdbI08oWd4upwi9cLx+4jwL0Ljewpp6OYvqJXHOphTlSLM1315J/ugHv7vxHgbNehhtCFyLdbBhtmEar0eCzlMfaZq7rY8xbWAi6xjlcJE7KKca/vhbMzfsASK8vst2ASbHrZEGBOio/rmem+57/4gWZ0L/+eVgbhYe/GUohl0qs9fGK/7siQt+AY4UpTyWQ3fd3HsSJS/m3EpjW5tlMxGGjNZPEu4ePC+58nCBXzODhXqJFdHIF1hACOKAM4ow6gi3s8Ripmz06EHTM4pKdEN0ikzktKN05iEHaXAztf+SFU61DfGKsnmVaCbruzSnZONCmyLZMJWNE6fXezBnY8h++dUbCfop+rDS/WKz4c4kCPBSv1OtnTTSwTgH9QLkO+XwuH/krKKGJq0D+AgqPsi4xItUUwRhcP0T2ojESO/+KiVv8uNZfAgb+jG/9QekxBmilysAfbOZBfJPCtSi9cBLuE87hQFZeWmZKO0RbZXQwvyFSg/ctezORQLuV3+yqNPs6eSoWW1k+CnQuMjY3N2A0/B7MKabxxHCUh7pJkgRYIVnFLDXSZae0uGo2w9AYwS3Vgh+JPGWyRJweL6sfD5XCih0N42/7T+JfST7fG2V1xor0/aFSVVlowcsJqsDDYnpuWhJhKOQ4rwzMrdiK17WS304aHV8yDi0tEWBXc3nAtqrigEJKhPZG+POy8craPUZ/UT8Fq0TbJk2JPzJRvsWO/5oET8xlLS/Pd+Ok9C1A+zrA9xmF9c12txubnsBb3FmKMnQ0SrDY5EdBmmQwl5lhtOMxhmIjEB14/oQQXvH2YObEEyxZPhYNuZwSRadaUCtg++AxBOlAJY+wc6lkhYrXRb1ZkQ5i3JBcScAgJsBw7Y2WHHWPyc1Ba4MHksYUo4VBt6ezGPTeVYUwZ/bQwGkl+U4Sd9aorCnH6/GWGpCG0jS8xcqWdFqw2OesZGQqkJ+/Qghp4th/UKteWF3CoMgbmN0m3zDfdPf8fCARRO4kLAvH+ulL9LTUlHQVdMCYXIGCZrZtnV0tpxiRYxcdHQqIMxBUxBHRPoEPimYiQK4fDlNs64EQG9rQGnGWOHH6LRrDCHKkiqWFiXk4eJzFSYXEupgUjMfkwQ5opYhX1GdGYUBBvHjuF3310CuOKI21ndbBbjUCk5/Se1HtRyo35RiuYb+H3KzS/sgSvHDyJNd5OI0faaVmiZLQcmRQYgPtcL/qP+HBNdCPOKkM5lvQs/a0DFz49z1AnFOSOM+k6ewH8+7swpy81d2cQNZwkVouczw7npJ7qtNtgK3bAXpmDhXMnaAKCsstBTz+C9J/ylkdAGvOEWfIiONHX40dlUS7GzyyFvcaFTtuIpbtwp0yC1SaH0Zy9JqRcO1rhtN2BX0wZh7llftBlYmxlkRYtjeg2Yw/qQHWwumK9EaScs4v3ch9KFl2LTTMq4HMpeKW0SOdM+y1YbXLyzqbOaFvh3cJ8yCNUv2QWqt/6JNLDbNKhXjQzUwcvZXpagPMZCIfx/HcbuCzMTpSlqSdWCS0JOHvUtHS25oa0bzBqvCZdAAnpb0lLeSwxr7Xdh+qbZ2QXLPUIVgkt98fqzOS3LNSLl81BSztXOMbvWAenv2OVyLcrZRLlU8anX5sZy5Hxb8EqbqmRLjK1tdwoqjeyl1ULh6JMXgIkOhElrCZgtX0dFdaSfHzEyC2bFMXYaIneltmXTeFe+uHPrq+KANBmbEo361mtR6NlWsMwg6D/VlOcTXN0WfsEqxZ4yG0ZPTdb719fW4lWiaxkKRuMANF6WkDqw1eUSVp6VhqGvIe4glrLBUa2SceoAZarQZxNMl9lG6zs53f4cN0EtEmIKYAHBRAfbdgKQD5y80GARsu+4LHqj+uqDVKyleQmnoYxEtlCdvM4xrdlS7wu56zLjm/dMBmncxg0SOQkAAflHQWpg2Xe3kI37ltQC1823VDUEMGm3/UaiqXlHpRuaDbfXXYLNpTnwTsYgD80iCCBh6NPkIsCyesM+vHShCLIhayrQUZsQ4Dl0pfcg7oaClUCCfI/H/emvdZ+XLL7tUfSPtnRoCtin18VEkzGC21DgEUb/dQvr4bWsHHzPRpRybrUweGby+2bMdzPymyjPb7VcpHNWDoCcOu85TvYIuuNDNlIBxUrbJy8XHRXeVwrF+e6UZLv4Tm4C26nkzscEuGOMCUbatmkyvrYW3tXfDTZOBDXra3r6sM9Fy5jEfes83lAph01iUZdq4xjeThjX2KjNBbmYmNlIT7LvfJqhC4z2TdVmB6I66pHyMnkysPCY148uvYQ8m0hlC9h8CGxP9dk2k6HdGJsR7IdNF8s76j7anvzHLyctZ/6wRwcrUgj4krlygPVaiQXQ2jDM/rvRO+J53x4dNMJ1O+9yDsd/QhwSeKzhpD/jWo4pvF2joCUpjU+IlDvYf1Nhf6PO9D3wUVes+NnwIrd1+Th/VvG4+nbJsMvDZcEUd3jrfPuetaMNaEEueHGFcYqs4rOQAi37DqPRzY0o/RMzB4CpXbZwwiyd/ME9HQuHUWTAIvVqOfx7d/Tib73LmgH47kDI4eC6rHjwvxivLq8FuuvKzczScvjxPsyQ8j74zHEqh/Bp11Mk1t4hotpNS0+3LvlDO7Yfhb5PQnWHJTcbQsz1gjDOWMMnHWFsE/i8IzVyOBj4JgP/Z90YuBUD3JUC3JDZJK1dBw6OrsEz6+Ygsb6ci5ShvkURdnjzrfddGLKMt4WMadhbvNyaFcPecPt+s87b1j9+nEs3pvCjV26Iz87ys/hLXtyCk8VLLkcqAWMvDhRhbqDvMrEjVgWyo6nK2hBTnhUk4Ysba3w4DX2+FtLatCT59jjVmx3nahb1jHEYJJISvrWpX90zm06KLfyVpnIGD2LWgYJPshH8MgtAFHMT51fqYUXYDivpQA0VqHfZXt589dnPvTIc4/E7Vm9TlKAdea2stWPsat+y7ho5AemM/yP3/SzYViUn5e3rzWdoMzMSQmwCGgvXb2UPc0L4rya838kgu3iN7uyrGPt1bsgLvhEAQfhNMWS/Ygs2fYT3WJDqmBFfso9bDSqo2LNjbxp8xR7vMGYf7XS7FH+Iw/rE6UXX9iZro6MAOtKO0oeWExP8jjnpCUc6sM75mUUL2eTfj5nODPJetiM5BhpInmlZgv5Lg8zcegG6aG2WVU8U3rprx8Ol6SXygpgXXVb2ZpyNRxeqSjq3eoMLMAcZfjwt41c/2QoJSGkh2rFT0lDyNHvMs6BeXwLyWy9KzSgnFX2qaryhsfqWJfX9qfMb7VEpGc2pKMyTF/qkw+623uDDYqqzOVyVw7dp6o9PIt28k6iI3qvKcBjHlkmu/lP8RQ00xU3q4q6v8xja1Se/EsWDpOuNO2/bQH0sPc/8NoAAAAASUVORK5CYII='
const girl = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAAAXNSR0IArs4c6QAADnJJREFUaAXFW2lsXNUV/t6bGY/H4zWJ4y0OJnZWyIpJAJmEtJQlISCCWAJCtEKBqlJVQWgrVaU/oAtqiUJbiYLUIlHRhKYSEAIJlAJJMQohTgJKIGQzWR07ju2MHXsWz8zrd97MHc8be+w344Ee683dzj33fO/ce+7yrjV8Q1TdsrWAopsMRK/SoM+EZsw0YFRqBoqg8REy0Gdo6NOgtcPQDpP3MHn3sqS5rXHVgMmT4x8tl/LqP3938kA4eL8GYzXlLjEM5GUjX9MQYr3dBrTXCpzujcfn33w+Gzkj1ckJ4Np9by+NGJGfEuAtNJtzpIayz9PCfAHvODTHH04vWvnf7OXEao4LcE3LW8vZDZ9iV20aryJ26rPrN+sO7ckzC1ftsMM/Ek9WgC9readqEKH1BLpmJKHfdB6Bb3Ihb93JxlvOZdpWxoCn7Hvz1mjU2GQAJZk2lkt+Ku7TdW3NmUW3b89Erp4Jc03LlnURw3jr/w1WdBYdRBfRKRMMtizccHSbe8AXeZHj9aFMhH9bvJzKXi4ocTx6bPqK4Fhtjgm4Yd+28gEjvMUwjGvHEqbKtWgU+R19KOj0wdUzgOLWDhSc6Ya75xJcl4JwDISgD0YQmuBFsMyLQHkxeubV4kJjPYIlHiUmo1DTtF0FmvOOY4tWdI5WcVTApmV7wx/aBauHIyg81QXv6W4gamDyJ0dRduA0HAGZVu2QBt/sapy8sxGdjdPsVLDwmKCLnctHs/Soc2asG9uzrOecDyVHziFS4EbZobOofP8gtEjUotDYCQMlrDuPT9/0CrQtvwLtfMLuUdVMiBXDiM7M+H4iMyWS1sLiDKjusyn8aZOTdx3DYKEHVz73NvJ6+i18DoeOSAp4eliThx7fwmtNaDh//UycXLUQvQ2V1qJRUvTET5xtvGP9SCwjApapRzwgXaFtL1658yvMfv49js1wop04JundtknXdUTpA5Kpe/5UnFm50H431xB1aNptI01ZwwDHFhXBQ+L2kxsdLV7x8RFcuf7tBItOi0ZTLJootBmRHpBs/d4ZFTi3dA7avjcXUZdjTCkE5nPBPTt1cTLMgrEVlH2wxa3nMefP7yYUyHM5xw1WhAlYrqgScouPdKDo5AVM3Pu1Ld8gBhMsCQHxiAXwlP1bb8hkuejsD2HeM29CDw1141BSl05tLNM0dUmCDFS/dwCezl4UH+/gymPscSJYBFNyuxbA0YjxdHLhWPG6N1rgvtCXYFOOKJGRg0gqLAGd1+untbtsSU/FlABMR7WMb8T2rsfdfQm1W2WvPkTJY24oN7cxLxcw+R0+FLJ7Sw8biwSTYFN8CcAcMk+oTDth3Rt7LV3ZTp1c8Vz2egu6FkyFi5a2Q8nYTMByUhHbvNupHuMp33XUPvM4OZfdOxuTphQnpEjv8rRdhL/K3kQi2ASjCDCXMHIsk8lJhTgNd9fQ2E1okuNI012zUFbhxbK7Z6FqWhnER2x5fi/6ewIo39NqLkPtNWk4YxjxnGnh+BmUvbrkmsSp4dugybTqstvL0L/3WUyvOYjZ19SA62Wz6Ul7WzNSQWHU46eLSzKpnd9+MRP2rHgLJ3gwo7ESfSc/gzfvPNz+PXA4NcxbWmvK87T7MpW7RLBKl25iH8/odNHNLV8uqcSbD19/wCIyGo7izNFulJXPQSDYA/ekWWj7/DwG+mKeWZawrksBrt/zLfXSJQQj+0aTLufG6ZjS5YvTyIY83PU41AI7LqBmYhFm1k0cJm6gN4hXnmrG5LpKtAea4J0yHwc+Oo3P3j+R4HV3WzcpiYI0EcHKTqLzgNy6WE/Dn8h2+gcT8Uwii+dUY+f+U5YqNzXV48tW6569lBa/GLf4hke3w3dhAKXlHlzstE5D9vfZsSYFqy5fBCwafEOJPKeOeXOrLNLFulcssOYJw303z0nwdbf1IRKKoOvsJTNMFGQTIVYnVyL2N5qjNOIkoII8V1qOxtmV0FwainlAoOjmpQ0ANz4et8vMFw9cU16IhjkVmP7pBHTEu2yUA/CSf+xVlZKbLhSsWnXLlgtcrw4fROlqMb/pkb9xDd1r4Zg/qxIPrpgbm9ll5ohPHyaTLIjzOQNKnj8yVC+faGWnF+CQCgsTScZ4Hnn7ySd5EQOtbT48/9qeWHnSb8sz98E3Y3gPSWKxRCm5y2l+2Iq3ZSnNMOEPcVx7qKiLj/h+BiYlyxZXUUiEkqfyJRSAyfOEbL7c5KNLRdBAfyA7n0EpVuJHPHOlZc21nyoqysety6djYlEBzvGUkl8Ah1eWrGSAwqHyJK6Ap8YlHSePOw8P3bkITvaI5j0ncPiY1ckpPjuhzgapaXa09qGrMd9ZiqqzOq6bPmVIiICQcx2xqDypoCRPKDVf0qkPsy6vLEXDgAd1nU784K6FqKwqktqZE7Hq8n0285pAMc+Pq7wehE744Zzi5iESNTWV5Y8CpAQrEKn5qlxC4RFK5qWzEtJYL39eIcLdg4ieDmJGQ0Yux5QhP4KVLoIfo7Ogvt4A/NTEUexA6GvOj36lKYUJMBmH4nTkkbQUS1dWoCWtSOWJP6OTgoRSLg/LdA5n//4+aNTWOdmF9vbsFj6ClV1aO0yxGRPPgPHy5n0IzfPAc3UxTg+wo0g3jnvWRCh5YikFOl1LCqxZn8wRZph1o2jrJthZBXDdUIoPDp7CkaMX0kkZPZ9YOQ9HswIsko+3duPXf9rBRb0DDVNLsbb2qpiFpA8mT0tcz5leWywmlBxKXB7TsowISCFJR1mPQZfPjw3//MQUOZ5TFcHKTmLeqYg1YvPXcEjfHKIoP7H4OX2YVhRLyiPHtBKK/qalGKaSiJFyASeh6gmql5ig2Wm40pKyVLCZ7pgEq8yWzTRGRsuY/poJrGalC+x2CYCivAxYBUABt1aJgVR5wmsSmXnzJfYCmEGsF7krGokCk+x76zjGZj1+W2b3SALT5flmWlc3omqAi4OLfVRMWVPprxYgIwlTPFKmhoDGCvKCJB0vP3K2a1htP6eqiM2tYbzybsFqqiO3ZYZJHCXj9MoFCPITZzIZ9PlftYozoUhRVhQ3Q8mSdJxbQCQ/kq3A8jNLDKSplhnv9Qdx/EyPwh4XArRfPwuhErkZZY8URlOyXA1iqzKR2KIwNwAHHrsVoVJvgp8Lc7y3u5Wb9bgYkSxjnZ9dTIelAKtQaibHhV+WksJvWpeFTDZ/cYqB/MXIYNmZVYswWOzJ4FuyFo5hpHgR0/PCK/3Fj65ZzOiMmNixf4McP+e+cwV0OiedU4irz48Qu7UoNqOWCwNRWgCLdQWZBKYHlghJGKXrCklclqUqLz5FneUh/6sfHDSzgxUl6Jp/GY49vByRPAfal83mBSlTfVPEaD/chW07tXDlX4Un3jogd63C0fDO0SqOWSaOh0B/efwc7mrnR3GZjmQzoUhFLUBZKGn18GgHg5x7uX5ec009epXF4zLktCXCAwK734ylmlN3LlN3vBKApaC65c2P2HmaJD5e+smJDjxwthsuWXImW1kES6umVVXIhFh1MBZ+WejGjxfWoZuWHC9xdcVrjLdfr+Sod26mOU/9ShWMN/xjXQV+dOVUfJnHQ7YAgdBqiaWmAJMnFA+DbC0YRQ+d1gvTJuGBJfU5ASsY5CJbMhaLhaWAVt5IK69JZhpvfLGvH48fOoXpcplFFsZiYhmzNLNhRHGJ3fbFaVV4taYMEbM3jLfFWH1adxOte3+ytGH7YbnhNojgCr57e98xkqWliX9a4sUOr47K07w452CTTj4uHgeZjs2JU4Ve/KN2+GImjThb2Xyd/CCety6V2dKlpVC+mPOTxhoaQdxIbolvMUaMqGsNw/qY4hlHSN0FQ+rXf5E4DLBkyt0ITok/k3iuqD6/MOasKFBWjk4e6Ll5JOQtdaGsegLKHOkPADPVQXQf6X6HyBkRsBTILRg6sZclni1NC1/Ew/4j2D/vJixzuZGfF0VhgcHDAwPeIh35hU44eZ41hWP5/fpr8Bu0Y3GoHS7TZWfXquic7gaPSBy1Q2V6MU0Eerjzv/vSIazpO4TKCDcUCx+nb6oA/r5eXGZs7Mr4lSNdJ0/ueCfEHNPlNcCN9wHb70WAkN8tuBwvFc7HKZd1CSttpCM7F9PSWliEyo02uc4ngtI1ovILoyGs7d2P7W2v4rGeXQQrH7voBrq/4EkllS4spcMiYFlImF5ailmutpGXzwU6D/Dl8NpiNIA7+r/C6+2b8bvuD1Af5iJmDDLBytXDMe5bjmph1cZYl0sXBdvx267/oCLMoxeRmHBOcQl1twHTab0e3uRvO8H5lxMv99Dmiyjii6it51zNHdHHP+dL4HFRSv0IR95fSq/GS8ULWDRcZenGObtcqkBLaN7O0/B7tmr2DJ3W+KGvBQ/7eP0hVUsLcirp5KXR0gZOdtPYnWlxnekgQQa4wzq/jy/BerBvfXOxt9jirsYvym9CpyO+SxJvTAc12phN1l/iw19XKkdKWl0QzzPCJRvOb8O1AycpRYkR08SUM8P42johwkxLKh3P2PUvOvKxtmo1jrsmZnVBXGma0MlORG7rbejYvP66/hOxFZlFf+l0zIjnycbOTFNwIq74VWMqzVAOB8eq3+P0bnpk6j3rPmp8kCuZzEiaypo6/3XjDWEj/LRmcMNBKxvc/iljm7aShFhVKCmu7GjWMQFay4Vd1U/IZH1Ka+bK88nyu3fsEJ5saFyAVYOdm5cvi0TDTxDvLbqmyRdJFsXsqqway1O5Q9YeqTy5fhRGWIf+jkPXny2/58Odqs1sw5wAVo13bPxuhaEH1hDuahpkCa3DiZbA2Yq8ApNi70KsZRo/Ucb8RJwujF6R/6iF15Dn3Vi5+t9077mhnAJOVsnYuqrgfH9Xk6EZV9GZz+Q8OZN9vpIgisgnj7yFPn5N6CPydg6Gw1xyHmZ672TvxGZt1dbcXiQxGwT+Bwfum9xpeZjeAAAAAElFTkSuQmCC'

const { TabPane } = Tabs;

//编码示例
// window.btoa('<script src="test.js"></script>'); 
// 输出："PHNjcmlwdCBzcmM9InRlc3QuanMiPjwvc2NyaXB0Pg=="
//解码示例
// window.atob("PHNjcmlwdCBzcmM9InRlc3QuanMiPjwvc2NyaXB0Pg=="); 
// 输出："<script src="test.js"></script>"

interface authData {
  date: string;
  count: number;
  [key: string]: any;
}

const pan1List = [
  { img: male, name: '度逍遥-磁性男声', type: 'tns', per: 5003, aue: 6 },
  { img: male, name: '度博文-情感男声', type: 'tns', per: 106, aue: 6 },
  { img: girl, name: '度小童-活泼女童', type: 'tns', per: 110, aue: 6 },
  { img: female, name: '度小鹿-甜美女声', type: 'tns', per: 5118, aue: 6 },
  { img: female, name: '度小娇-情感女声', type: 'tns', per: 5, aue: 6 },
  { img: girl, name: '度米朵-可爱女童', type: 'tns', per: 103, aue: 6 },
]
// const API_KEY = 'uq1hQw6B0RukaQZuXIrwtbyg' // 自己的
// const SECRET_KEY = 'Y3RynXcxOZ9j8XFujPYhOWUfMMBSI3IM' // 自己的

const synth = window.speechSynthesis
const notifiTimeout = 2
let utterThis = new SpeechSynthesisUtterance()
let countTimer: any = null

const App = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [speakSwitch, setSpeakSwitch] = useState<boolean>(true);
  const [autoSpeak, setAutoSpeak] = useState<boolean>(true);
  const [audioSrc, setAudioSrc] = useState<string>('');
  const [readText, setReadText] = useState<any>('');
  const [buttonText, setButtonText] = useState('播放');
  const [active, setActive] = useState<number>(0);
  const [tabsKey, setTabsKey] = useState<string>('1');

  const accessTokenRef = useRef<string>('');
  const audioRef = useRef<any>();
  const buttonRef = useRef<any>();
  const speakRef = useRef<any>(true);
  const autoSpeakRef = useRef<any>(true);
  const autoSpaekNext = useRef<boolean>(false); // 此变量产生背景(因为调用百度语音时, audio标签生成了src后,必须是触发了onCanPlay后点击"播放"才会有效果,否则会被 btn按钮的loading阻挡)
  const countRef = useRef<boolean>(false);
  const activeRef = useRef<number>(0);
  const tabsKeyRef = useRef<string>('1');
  const spdRef = useRef<number>(5);
  const spd2Ref = useRef<number>(5);
  const pitRef = useRef<number>(5);
  const volRef = useRef<number>(5);
  const licenceRef = useRef<string>(localStorage.getItem('licence') || '');

  const [spd, setSpd] = useState(5); // 语速，取值0-15，默认为5中语速
  const [spd2, setSpd2] = useState<boolean>(1); // 系统原声的语速，取值0-5，默认为1
  const [pit, setPit] = useState(5); // 音调，取值0-15，默认为5中语调
  const [vol, setVol] = useState(5); // 音量，取值0-15，默认为5中音量（取值为0时为音量最小值，并非为无声）
  const [auth, setAuth] = useState<authData>(JSON.parse(localStorage.getItem('auth') || '{}'));
  const [licence, setLicence] = useState<string>(localStorage.getItem('licence') || '');
  const [inputLicence, setInputLicence] = useState<string>(localStorage.getItem('inputLicence'));
  const [inputValue, setInputValue] = useState<string>('');
  const [visible, setVisible] = useState<boolean>(false);

  const maxCounter: number = useMemo(() => {
    return 120 - (readText?.length || 0)
  }, [readText])
  const authStatus: boolean = useMemo(() => {
    if (tabsKey !== '1') return true
    else return licence === inputLicence
  }, [licence, inputLicence, tabsKey])
  const encryptionLicence: string = useMemo(() => {
    return btoa(licence || '')
  }, [licence])

  const onSetAuth = (auth: authData) => {
    setAuth(auth)
    localStorage.setItem('auth', JSON.stringify(auth))
  }
  const onInputValue = (e: any) => {
    setInputValue(e.target.value)
  }
  const getDate = () => {
    return new Date().toLocaleDateString(); //获取当前日期
  }
  const getBaiduToken = () => {
    return new Promise((resolve, reject) => {
      if (accessTokenRef.current) {
        resolve(accessTokenRef.current)
      } else {
        fetch(`${accessTokenUrl}?grant_type=client_credentials&client_id=${API_KEY}&client_secret=${SECRET_KEY}`)
          .then(function (response) {
            return response.json()
          })
          .then(res => {
            accessTokenRef.current = res.access_token
            resolve(res.access_token)
          })
          .catch(err => {
            reject(err)
          })
      }
    })
  }
  const onOk = () => {
    const _inputValue = inputValue?.replace(/\'/g, '').replace(/\"/g, '');
    if (_inputValue) {
      if (_inputValue == licence) {
        setInputLicence(_inputValue)
        localStorage.setItem('inputLicence', _inputValue)
        notification.success({
          message: '',
          description: '解密成功',
          placement: 'bottomRight',
          duration: notifiTimeout,
        });
        setVisible(false)
      } else {
        notification.error({
          message: '',
          description: '密钥不一致, 请重新操作',
          placement: 'bottomRight',
          duration: notifiTimeout,
        });
      }
    }
  }
  const getAudioSrc = (text: string) => {
    return new Promise((resolve, reject) => {
      getBaiduToken().then(token => {
        const audioUrl = `${text2audioUrl}?tok=${token}&tex=${encodeURIComponent(encodeURIComponent(text))}&cuid=${licenceRef.current}&lan=zh&ctp=1&vol=${volRef.current}&per=${pan1List[activeRef.current].per}&spd=${spdRef.current}&pit=${pitRef.current}&aue=3&timestamp=${new Date().getTime()}`
        resolve(audioUrl)
      })
    })
  }
  const handleSpeak = async (text: string, event?: any) => {
    setLoading(true)
    try {
      const _audioSrc: any = await getAudioSrc(text)
      setAudioSrc(_audioSrc)
      autoSpaekNext.current = true
      event && event.sender.send('read-text-value', text)
    } catch (err) {
      console.log(err)
      setLoading(false)
    }
  }
  const buttonClick = () => {
    if (!readText) {
      notification.warn({
        message: '',
        description: '请复制文本',
        placement: 'bottomRight',
        duration: notifiTimeout,
      });
      return
    }
    if (tabsKeyRef.current === '1') {
      if (audioSrc) {
        if (buttonText === '播放') {
          if (!authStatus && auth?.count >= 10) { // 未解密,每天只能免费10次
            setVisible(true)
          } else {
            onSetAuth({
              date: auth?.date,
              count: auth?.count ? auth.count + 1 : 1,
            })
            setButtonText('暂停')
            audioRef?.current?.play()
          }
        } else {
          setButtonText('播放')
          audioRef?.current?.pause()
        }
      } else {
        handleSpeak(readText)
      }
    } else if (tabsKeyRef.current === '2') {
      if (buttonText === '暂停') {
        synthPause()
      } else {
        if (!synth.paused && !synth.pending && !synth.speaking) { // 全关闭状态,说话需重新读取
          speak(readText)
        } else if (utterThis?.text !== readText) { // 读到一半,暂停,再修改输入框,此时新text和旧text不一样,需重新读取
          synthCancel()
          speak(readText)
        } else {
          synthResume()
        }
      }
    }
  }
  const synthSpeak = () => { // 播放
    synth.speak(utterThis)
    setButtonText('暂停')
  }
  const synthPause = () => { // 暂停
    synth.pause()
    setButtonText('播放')
  }
  const synthResume = () => { // 继续
    synth.resume()
    setButtonText('暂停')
  }
  const synthCancel = () => { // 关闭
    setButtonText('播放')
    if (synth.paused || synth.pending || synth.speaking) { // 全关闭状态,说话需重新读取
      synth.cancel()
    }
  }
  const ended = () => {
    setButtonText('播放')
  }
  const onClear = () => {
    setReadText('')
    setButtonText('播放')
    setLoading(false)
    if (tabsKeyRef.current === '1') { // 百度语音
      audioRef?.current?.pause()
      setAudioSrc('')
    } else if (tabsKeyRef.current === '2') { // 系统原声
      synthCancel()
    }
  }
  const onPaneClick = (item: any, index: number) => {
    setActive(index);
    activeRef.current = index
    setLoading(false)
    setButtonText('播放')
    if (tabsKeyRef.current === '1') { // 百度语音
      audioRef?.current?.pause()
      setAudioSrc('')
    } else if (tabsKeyRef.current === '2') { // 系统原声
      synthCancel()
    }
  }
  const onSPD = (value: number) => {
    audioRef?.current?.pause()
    setSpd(value)
    spdRef.current = value
    setAudioSrc('')
    setLoading(false)
    setButtonText('播放')
  }
  const onPIT = (value: number) => {
    audioRef?.current?.pause()
    setPit(value)
    pitRef.current = value
    setAudioSrc('')
    setLoading(false)
    setButtonText('播放')
  }
  const onVOL = (value: number) => {
    audioRef?.current?.pause()
    setVol(value)
    volRef.current = value
    setAudioSrc('')
    setLoading(false)
    setButtonText('播放')
  }
  const onSPD2 = (value: number) => {
    setSpd2(value)
    spd2Ref.current = value
    synthCancel()
    setLoading(false)
    setButtonText('播放')
  }
  const onSpeakSwitch = () => {
    setSpeakSwitch(!speakSwitch)
    speakRef.current = !speakSwitch
    setLoading(false)
    if (!speakRef.current) {
      setButtonText('播放')
      if (tabsKeyRef.current === '1') { // 百度语音
        audioRef?.current?.pause()
        setAudioSrc('')
      } else if (tabsKeyRef.current === '2') { // 系统原声
        synthCancel()
      }
    }
  }
  const onAutoSpeak = () => {
    setAutoSpeak(!autoSpeak)
    autoSpeakRef.current = !autoSpeak
  }
  const onTabs = (value: string) => {
    if (tabsKeyRef.current === '1') { // 百度语音
      audioRef.current.pause()
      setAudioSrc('')
    } else if (tabsKeyRef.current === '2') { // 系统原声
      synthCancel()
    }
    setButtonText('播放')
    setTabsKey(value)
    tabsKeyRef.current = value
    setLoading(false)
  }
  function speak(txt: string) {
    utterThis.text = txt;
    utterThis.rate = spd2Ref.current;
    utterThis.lang = 'zh-CN';
    synthSpeak()
    utterThis.onend = () => {
      synthCancel()
    }
  }
  const onTextarea = async (e: any) => {
    let { value } = e.target
    if (value?.length > 120) {
      value = value.slice(0, 120)
      if (!countRef.current) {
        countRef.current = true
        notification.info({
          message: '',
          duration: notifiTimeout,
          placement: 'bottomRight',
          description: '最多只能输入120个字符',
        });
        countTimer = setTimeout(() => {
          countRef.current = false
        }, notifiTimeout * 1000);
      }
    }
    setReadText(value)
    setButtonText('播放')
    setLoading(false)
    if (tabsKeyRef.current === '1') { // 百度语音
      audioRef?.current?.pause()
      setAudioSrc('')
    } else if (tabsKeyRef.current === '2') { // 系统原声
      synthCancel()
    }
  }
  const onCanPlay = (e: any) => {
    setLoading(false)
    if (autoSpaekNext.current) {
      buttonRef?.current?.click()
      autoSpaekNext.current = false
    }
  }
  useEffect(() => {
    getBaiduToken();
  }, [])
  useEffect(() => {
    if (!licence) { // 初始化licence
      const random = getRandomString()
      setLicence(random)
      licenceRef.current = random
      localStorage.setItem('licence', random)
    }
    if (licence !== inputLicence) { // 未获得授权, 去做初始化操作
      const date = getDate()
      let auth: any = JSON.parse(localStorage.getItem('auth') || '{"date":"","count":0}') ;
      if (auth?.date !== date) { // 第二天,发现date不一样,就去更新date
        auth = { date, count: 0 }
        setAuth(auth)
        localStorage.setItem('auth', JSON.stringify(auth))
      }
    }
  }, [])
  useEffect(() => {
    window?.electronAPI?.handleReadText(async (event: any, text: string) => {
      if (!speakRef.current) {
        return
      }
      if (text?.length > 120) {
        notification.info({
          message: '',
          description: '最多只能输入120个字符',
          placement: 'bottomRight',
          duration: notifiTimeout,
        });
        text = text.slice(0, 120)
      }
      setAudioSrc('')
      setReadText(text)
      setLoading(false)
      setButtonText('播放')
      if (autoSpeakRef.current) {
        if (text && readText !== text) {
          if (tabsKeyRef.current == '1') { // 系统原声
            handleSpeak(text, event)
          } else {
            synthCancel()
            speak(text)
          }
        }
      }
    })
  }, [])
  return (
    <>
      <AppBox
        style={{
          pointerEvents: speakSwitch ? 'auto' : 'none',
          filter: speakSwitch ? 'none' : 'grayscale(100%)',
          userSelect: speakSwitch ? 'text' : 'none'
        }}>
        <LeftBox>
          <Textarea value={readText} onChange={onTextarea}></Textarea>
          <TextareaDesc>
            <div style={{ letterSpacing: '0.5px', height: '16px', color: '#666' }}>
              <span>您还可输入</span>
              <span style={{ margin: '0 2px', color: '#ff851a' }}>{maxCounter}</span>
              <span>字</span>
            </div>
            <CloseSvg onClick={onClear} viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2004">
              <path d="M514.133333 85.333333c-238.933333 0-426.666667 187.733333-426.666666 426.666667C87.466667 746.666667 277.333333 938.666667 512 938.666667c234.666667 0 426.666667-192 426.666667-426.666667 0-236.8-192-426.666667-424.533334-426.666667z m162.133334 558.933334c8.533333 8.533333 8.533333 21.333333 0 29.866666-4.266667 4.266667-10.666667 6.4-14.933334 6.4-6.4 0-10.666667-2.133333-14.933333-6.4L512 539.733333l-136.533333 134.4c-4.266667 4.266667-10.666667 6.4-14.933334 6.4-6.4 0-10.666667-2.133333-14.933333-6.4-8.533333-8.533333-8.533333-21.333333 0-29.866666l134.4-134.4-134.4-134.4c-8.533333-8.533333-8.533333-21.333333 0-29.866667 8.533333-8.533333 21.333333-8.533333 29.866667 0l134.4 134.4 134.4-134.4c8.533333-8.533333 21.333333-8.533333 29.866666 0 8.533333 8.533333 8.533333 21.333333 0 29.866667l-134.4 134.4 136.533334 134.4z" p-id="2005"></path>
            </CloseSvg>
          </TextareaDesc>
        </LeftBox>
        <RightBox>
          <Tabs animated activeKey={tabsKey} onChange={onTabs}>
            <TabPane tab="臻品音库(需联网)" key="1">
              <div>
                <TabsPan1>
                  {
                    pan1List.map((item: any, index) => {
                      return (
                        <PaneItem
                          onClick={() => onPaneClick(item, index)}
                          key={item.per}
                          style={{
                            color: active == index ? '#1a73e8' : '',
                            backgroundColor: active == index ? 'rgba(26, 155, 232, .06)' : '',
                            backgroundImage: `url(${item.img})`
                          }}
                        >
                          {item.name}
                        </PaneItem>
                      )
                    })
                  }
                </TabsPan1>
                <SliderSetting>
                  <span>语速</span>
                  <Slider style={{ flex: 1 }} value={spd} max={15} onChange={onSPD} />
                  <span style={{ minWidth: 16 }}>x{spd}</span>
                </SliderSetting>
                <SliderSetting>
                  <span>音调</span>
                  <Slider style={{ flex: 1 }} value={pit} max={15} onChange={onPIT} />
                  <span style={{ minWidth: 16 }}>{pit}</span>
                </SliderSetting>
                <SliderSetting>
                  <span>音量</span>
                  <Slider style={{ flex: 1 }} value={vol} max={15} onChange={onVOL} />
                  <span style={{ minWidth: 16 }}>{vol}</span>
                </SliderSetting>
              </div>
            </TabPane>
            <TabPane tab="本地语音(无需联网)" key="2">
              <div>
                <TabsPan2>
                  <PaneItem
                    style={{
                      color: '#1a73e8',
                      backgroundColor: 'rgba(26, 155, 232, .06)',
                      backgroundImage: `url(${defaultMale})`
                    }}
                  >
                    默认-系统原声
                  </PaneItem>
                </TabsPan2>
                <SliderSetting style={{ paddingTop: '30px' }}>
                  <span>语速</span>
                  <Slider style={{ flex: 1 }} step={0.1} value={spd2} max={10} onChange={onSPD2} />
                  <span style={{ minWidth: 16 }}>x{spd2}</span>
                </SliderSetting>
              </div>
            </TabPane>
          </Tabs>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <SwitchBox>
              <span style={{ marginRight: '5px' }}>自动阅读开关:</span>
              <Switch
                checked={autoSpeak}
                checkedChildren="开启"
                unCheckedChildren="关闭"
                onChange={onAutoSpeak}
              />
            </SwitchBox>
            <Button
              ref={buttonRef}
              type="primary"
              onClick={buttonClick}
              loading={loading}
              style={{
                width: '108px',
                height: '40px',
                position: 'absolute',
                right: '24px',
                bottom: '20px'
              }}
            >
              {!loading && buttonText === '播放' && (
                <svg style={{ marginRight: '5px', width: '14px', height: '14px', verticalAlign: 'middle', fill: 'currentColor', overflow: 'hidden' }} viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1677">
                  <path d="M817.088 484.96l-512-323.744C295.232 154.976 282.752 154.592 272.576 160.224 262.336 165.856 256 176.608 256 188.256l0 647.328c0 11.648 6.336 22.4 16.576 28.032 4.8 2.656 10.112 3.968 15.424 3.968 5.952 0 11.904-1.664 17.088-4.928l512-323.616C826.368 533.184 832 522.976 832 512 832 501.024 826.368 490.816 817.088 484.96z" p-id="1678"></path>
                </svg>
              )}
              {!loading && buttonText === '暂停' && (
                <PlayingIcon>
                  <Line className="line1" />
                  <Line className="line2" />
                  <Line className="line3" />
                </PlayingIcon>
              )}
              {!loading && <span>{buttonText}</span>}
            </Button>
          </div>
          {tabsKey === '1' && (
            <audio
              ref={audioRef}
              src={audioSrc}
              onEnded={ended}
              onCanPlay={onCanPlay}
              style={{ opacity: 0 }}
            ></audio>
          )}
        </RightBox>
      </AppBox>
      <SwitchBox2>
        <span style={{ marginRight: '5px' }}>语音总开关:</span>
        <Switch
          checked={speakSwitch}
          checkedChildren="开启"
          unCheckedChildren="关闭"
          onChange={onSpeakSwitch}
        />
      </SwitchBox2>
      <Modal
        onOk={onOk}
        okText="确认"
        cancelText="取消"
        visible={visible}
        onCancel={() => setVisible(false)}
        okButtonProps={{ disabled: !inputValue?.length }}
      >
        <p style={{ marginTop: '20px' }}>该音库需联网, 每天有10次免费机会</p>
        <p style={{ margin: '50px 0' }}>如需解锁限制, 请联系下方微信,发送下方加密密钥来获取解锁密钥: </p>
        <p style={{ display: 'flex', alignItems: 'center', marginBottom: '50px' }}>
          <span>加密密钥: </span>
          <span style={{ fontWeight: 600, fontSize: '16px', color: '#bc0722' }}>{encryptionLicence}</span>
        </p>
        <p style={{ display: 'flex', alignItems: 'center', marginBottom: '50px' }}>
          <span>微信: </span>
          <span style={{ fontWeight: 600, fontSize: '16px', color: '#bc0722' }}>Xiyuzhuli</span>
        </p>
        <p style={{ display: 'flex', alignItems: 'center', marginBottom: '50px' }}>
          <span>解锁密钥: </span>
          <Input placeholder="Please input" style={{ marginLeft: '10px', height: '40px', flex: 1 }} value={inputValue} onChange={onInputValue}/>
        </p>
      </Modal>
    </>
  )
}

export default App;
