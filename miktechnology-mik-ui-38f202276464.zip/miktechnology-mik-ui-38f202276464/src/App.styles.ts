import styled, { keyframes } from 'styled-components'

const voicePlay1 = keyframes`
  0% {
    opacity: 0;
  }
  33% {
    opacity: 1;
  }
`;

const voicePlay2 = keyframes`
  30% {
    opacity: 0;
  }
  66% {
    opacity: 1;
  }
`;

const voicePlay3 = keyframes`
  66% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
`;

export const AppBox: any = styled.div`
  display: flex;
  height: 500px;
  min-height: 462px;
  border: 1px solid #d6d6d6;
`;

export const LeftBox: any = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  width: 40%;
  padding: 24px;
  box-sizing: border-box;
  border-right: 1px solid #d6d6d6;
`;

export const RightBox: any = styled.div`
  position: relative;
  flex: 1;
  padding: 24px;
  background: #f6f6f6;
  box-sizing: border-box;
  overflow: hidden;
`;

export const Textarea: any = styled.textarea`
  display: block;
  width: 100%;
  height: 100%;
  flex: 1;
  padding: 0;
  line-height: 30px;
  resize: none;
  background-color: transparent;
  font-size: 14px;
  outline: none;
  border: 0;
  color: #000;
  box-sizing: border-box;
`;

export const TextareaDesc: any = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

export const CloseSvg: any = styled.svg`
  color: #999;
  width: 24px;
  height: 24px;
  cursor: pointer;
  overflow: hidden;
  fill: currentColor;
  border-radius: 50%;
  vertical-align: middle;
  transition: transform .15s;
  &: hover {
    transform: scale(1.1) rotateZ(90deg);
  }
`;

export const TabsPan1: any = styled.div`
  height: 196px;
  overflow: hidden;
  padding: 20px 24px;
  margin-bottom: 24px;
  box-sizing: border-box;
  background-color: #fff;
  border: 1px solid #d6d6d6;
`;

export const TabsPan2: any = styled.div`
  height: 196px;
  overflow: hidden;
  padding: 20px 24px;
  margin-bottom: 24px;
  box-sizing: border-box;
  background-color: #fff;
  border: 1px solid #d6d6d6;
`;

export const PaneItem: any = styled.div`
  float: left;
  padding-left: 55px;
  margin: 0 13px 12px 0;
  border: 1px solid #fff;
  width: 177px;
  height: 44px;
  line-height: 44px;
  background-size: 30px;
  background-repeat: no-repeat;
  background-position: 15px 7px;
  cursor: pointer;
  box-sizing: border-box;
  &.active {
    color: #1a73e8;
    background-color: rgba(26, 155, 232, .06);
  }
`;

export const SliderSetting: any = styled.div`
  display: flex;
  align-items: center;
  position: relative;
  margin-bottom: 20px;
  .ant-slider {
    &:hover {
      .ant-slider-rail {
        background-color: #cdcdcd;
      }
      .ant-slider-handle {
        border-color: #22B8DD;
      }
    }
    margin: 0 6px;
    .ant-slider-track {
      background-color: #3682f9;
    }
    .ant-slider-handle {
      border-color: #3682f9;
      background-color: #3682f9;
    }
    .ai-range-track {
      background-color: #3682f9;
    }
    .ant-slider-rail {
      background-color: #ebebeb;
    }
  }
`;

export const SwitchBox2: any = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 100px;
`

export const SwitchBox: any = styled.div`
  position: absolute;
  left: 24px;
  bottom: 20px;
`

export const PlayingIcon: any = styled.div`
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  vertical-align: sub;
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAACshmLzAAABfUlEQVRYCe2WPUgDMRiGe0UR6g+46drBExdHHdwKopO7ThVcBDcVFCelIKjgUGc7O7k6OXdwEergqouj6CBWjM8HKdhwd73E/kjJBw/Jl7/3veS4XCbjo192QCk1Dcu2z5O1nWCOR3QUTmi/h4LZ3yofaDUgqR/hNfpFfDJpXFKfkwGEZ1m0DAt68XfKEV23KqyOAOFxuEDhDkT8BYpwBE6RygCiWdhA4RE2QcE5hEEQVHROYR9NR4DIHkvsRywjRnO6/ZZyC+FaxDjrpiYDzB6CuLN8om8b4StrlYQJpoHG0GMqpUaiyw/Ev4y2P6dxBj4Rkze745HqJeykC2/A74DfgX+7AwfcC3WDGvliu78JcTsg7fKV/M0M+Q0mriHfLiOmgUMWHoxAbsJdeIMVeMBECYapdy8QnIAKfIPEM6zCjiTEaVfcIDQHVVHU8apLawPmEaR6AG7KKgPnYR3kt2wMnMLJgChhQsEl1Sk4gzr0LjiCEJZ658ArO+7AD/WhqQavZsabAAAAAElFTkSuQmCC);
  background-size: contain;
  margin-right: 5px;
  margin-bottom: 1px;
`

export const Line: any = styled.div`
  position: absolute;
  right: 1px;
  width: 4px;
  height: 1px;
  background-color: #fff;
  opacity: 0;
  &.line1 {
    top: 25%;
    transform: rotate(-38deg);
    animation: ${voicePlay1} 2s infinite;
  }
  &.line2 {
    top: 52%;
    right: 2px;
    width: 3px;
    animation: ${voicePlay2} 2s infinite;
  }
  &.line3 {
    bottom: 14%;
    transform: rotate(40deg);
    animation: ${voicePlay3} 2s infinite;
  }
`
