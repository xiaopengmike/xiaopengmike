import { api } from '../../electron/bridge'

interface electronAPITypes {
  handleReadText: Function
}

declare global {
  // eslint-disable-next-line
  interface Window {
    Main: typeof api;
    electronAPI: electronAPITypes;
  }
}

declare module "*.svg" {
  const content: any;
  export default content;
}
